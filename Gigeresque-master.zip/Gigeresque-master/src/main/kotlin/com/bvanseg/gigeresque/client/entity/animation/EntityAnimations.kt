package com.bvanseg.gigeresque.client.entity.animation

import com.bvanseg.gigeresque.common.Gigeresque
import net.minecraft.util.Identifier

/**
 * @author Boston Vanseghi
 */
object EntityAnimations {
    val ALIEN = Identifier(Gigeresque.MOD_ID, "animations/alien.animation.json")
    val AQUATIC_ALIEN = Identifier(Gigeresque.MOD_ID, "animations/aquatic_alien.animation.json")
    val AQUATIC_CHESTBURSTER = Identifier(Gigeresque.MOD_ID, "animations/aquatic_chestburster.animation.json")
    val CHESTBURSTER = Identifier(Gigeresque.MOD_ID, "animations/chestburster.animation.json")
    val EGG = Identifier(Gigeresque.MOD_ID, "animations/egg.animation.json")
    val FACEHUGGER = Identifier(Gigeresque.MOD_ID, "animations/facehugger.animation.json")
    val RUNNER_ALIEN = Identifier(Gigeresque.MOD_ID, "animations/runner_alien.animation.json")
    val RUNNERBURSTER = Identifier(Gigeresque.MOD_ID, "animations/runnerburster.animation.json")
}