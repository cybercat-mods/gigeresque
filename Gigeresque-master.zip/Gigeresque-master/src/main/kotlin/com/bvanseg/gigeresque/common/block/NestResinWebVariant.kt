package com.bvanseg.gigeresque.common.block

import net.minecraft.util.StringIdentifiable

/**
 * @author Boston Vanseghi
 */
enum class NestResinWebVariant(private val dirName: String): StringIdentifiable {
    ONE("one"),
    TWO("two"),
    THREE("three"),
    FOUR("four"),
    FIVE("five"),
    SIX("six");

    override fun asString(): String = dirName
}