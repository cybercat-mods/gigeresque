package com.bvanseg.gigeresque.common.entity

/**
 * @author Boston Vanseghi
 */
enum class GenericAlienAttackType {
    NONE,
    BITE,
    CLAW,
    TAIL;
}