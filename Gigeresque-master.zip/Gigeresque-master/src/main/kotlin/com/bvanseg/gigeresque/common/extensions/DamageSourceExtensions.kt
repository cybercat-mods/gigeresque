package com.bvanseg.gigeresque.common.extensions

import net.minecraft.entity.damage.DamageSource

/**
 * Is a damage source that does not puncture the target.
 */
val DamageSource.isNotPuncturing
    get() = this.isExplosive || this.isFire || this.isMagic || this.isFromFalling || this.isFallingBlock