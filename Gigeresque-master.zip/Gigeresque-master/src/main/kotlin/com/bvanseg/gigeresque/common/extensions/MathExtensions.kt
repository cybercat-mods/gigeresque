package com.bvanseg.gigeresque.common.extensions

import java.text.NumberFormat

/**
 * @author Boston Vanseghi
 */
private val numberFormat = NumberFormat.getNumberInstance()

/**
 * Formats this number to a [String] with digit grouping.
 *
 * @author Boston Vanseghi
 */
fun Number.format(): String = numberFormat.format(this)