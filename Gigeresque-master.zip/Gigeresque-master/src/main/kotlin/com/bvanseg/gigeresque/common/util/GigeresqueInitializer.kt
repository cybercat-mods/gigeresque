package com.bvanseg.gigeresque.common.util

/**
 * @author Boston Vanseghi
 */
interface GigeresqueInitializer {
    fun initialize()
}