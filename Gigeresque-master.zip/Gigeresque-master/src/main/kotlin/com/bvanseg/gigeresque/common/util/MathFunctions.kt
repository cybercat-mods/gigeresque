package com.bvanseg.gigeresque.common.util

/**
 * @author Boston Vanseghi
 */
fun <T : Comparable<T>> clamp(value: T, min: T, max: T): T = when {
    value < min -> min
    value > max -> max
    else -> value
}